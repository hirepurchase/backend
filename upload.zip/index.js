// IISNode entry point wrapper
// This file loads the actual compiled application from dist/index.js
require('./dist/index.js');
